package com.example.user.chat_app;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.firebase.client.ChildEventListener;
import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

import static com.example.user.chat_app.R.*;

public class Users_list extends AppCompatActivity {


   private ListView listv;
    // ListView usersList;
    //TextView user1, user2, user3, user4, user5;
    //ArrayList<String> al = new ArrayList<>();
   // int totalUsers = 0;
    ProgressDialog pd;
     private Firebase mref;
    //private FirebaseAuth mau;
   // private DatabaseReference alldatabaseuserreference;
    private  ArrayList<String> musername = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(layout.activity_users_list);
        Firebase.setAndroidContext(getApplicationContext());
        listv = (ListView)findViewById(id.lv);
        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, layout.activity_users_list);
        listv.setAdapter(arrayAdapter);
        mref = new Firebase("https://chat-app-c8df8.firebaseio.com/users");

        mref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String value = dataSnapshot.child("Name").getValue().toString();
                musername.add(value);
                arrayAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });
       // alluserslist = (RecyclerView) findViewById(id.rec);
        //alluserslist.setHasFixedSize(true);
        //alluserslist.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        //alldatabaseuserreference = FirebaseDatabase.getInstance().getReference().child("users");

        Toolbar toolbar = (Toolbar) findViewById(id.toolbar);
        setSupportActionBar(toolbar);
        //usersList = (ListView)findViewById(R.id.usersList);
        // user1 = (TextView)findViewById(R.id.username1);
       // mau = FirebaseAuth.getInstance();
        //  String user_id =  mau.getCurrentUser().getUid();
      //  pd = new ProgressDialog(Users_list.this);
       // pd.setMessage("Loading...");
        //pd.show();
        //pd.dismiss();






        FloatingActionButton fab = (FloatingActionButton) findViewById(id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Snackbar.make(view, "Profile Information", Snackbar.LENGTH_LONG)
                       // .setAction("Action", null).show();
                Intent pro = new Intent(getApplicationContext(),Profile.class);
                startActivity(pro);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();



    }

    public static class AllUsersViewholder extends RecyclerView.ViewHolder
    {
        View mv;

        public AllUsersViewholder(View itemView) {
            super(itemView);
            mv=itemView;
        }
    }
}

//String url = "https://chat-app-c8df8.firebaseio.com/users/Name";
//
// String online_user_id = mau.getCurrentUser().getUid();
// getref = FirebaseDatabase.getInstance().getReference().child("users").child(online_user_id);

        /*getref.addValueEventListener(new com.google.firebase.database.ValueEventListener() {
            @Override
            public void onDataChange(@NonNull com.google.firebase.database.DataSnapshot dataSnapshot)
            {
                String value = dataSnapshot.child("Name").getValue().toString();*/
                /*user1.setText(value);
                user3.setText(value);
                user4.setText(value);
                user5.setText(value);
*/



                    /* FirebaseRecyclerAdapter<AllUsers, AllUsersViewholder> firebaseRecyclerAdapter
                = new FirebaseRecyclerAdapter<AllUsers, AllUsersViewholder>
                (
                        AllUsers.class,
                        layout.user_card,
                        AllUsersViewholder.class,
                        alldatabaseuserreference

                )
        {
            @Override
            protected void onBindViewHolder(@NonNull AllUsersViewholder holder, int position, @NonNull AllUsers model) {

            }

            @NonNull
            @Override
            public AllUsersViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return null;
            }
        };




        {
            @Override
            protected void onBindViewHolder(@NonNull AllUsersViewholder holder, int position, @NonNull AllUsers model)
            {

            }

            @NonNull
            @Override
            public AllUsersViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return null;
            }
        };
*/

