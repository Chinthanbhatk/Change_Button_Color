package com.example.user.chat_app;

public class AllUsers {
    public String uname;

    public AllUsers()
    {

    }

    public AllUsers(String uname) {
        this.uname = uname;
    }

    public String getName() {
        return uname;
    }

    public void setName(String name) {
        this.uname = name;
    }
}
